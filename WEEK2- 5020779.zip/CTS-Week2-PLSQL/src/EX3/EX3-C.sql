/*
Scenario 3: Customers should be able to transfer funds between their accounts.
Question: Write a stored procedure TransferFunds that transfers a specified amount from one account to another, checking that the source account has sufficient balance before making the transfer.
*/

CREATE OR REPLACE PROCEDURE TransferFunds (
  p_from_account_id NUMBER,
  p_to_account_id NUMBER,
  p_amount NUMBER
)
IS
  v_from_account_balance NUMBER;
BEGIN
  -- Check for sufficient funds
  SELECT balance INTO v_from_account_balance
  FROM accounts
  WHERE account_id = p_from_account_id;

  IF v_from_account_balance < p_amount THEN
    RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds');
  END IF;

  -- Transfer funds
  UPDATE accounts
  SET balance = balance - p_amount
  WHERE account_id = p_from_account_id;

  UPDATE accounts
  SET balance = balance + p_amount
  WHERE account_id = p_to_account_id;
END;
/
