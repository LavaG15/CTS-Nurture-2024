/*
Scenario 3: Ensure data integrity when adding a new customer.
Question: Write a stored procedure AddNewCustomer that inserts a new customer into the Customers table. If a customer with the same ID already exists, handle the exception by logging an error and preventing the insertion.
*/

CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_customer_id NUMBER,
    p_name VARCHAR2(100),
    p_dob DATE,
    p_balance NUMBER
)
IS
BEGIN
  INSERT INTO customers (customer_id, name, dob, balance)
  VALUES (p_customer_id, p_name, p_dob, p_balance);

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(-20003, 'Customer ID already exists');
    WHEN OTHERS THEN
      -- Log error here (e.g., using DBMS_LOG or custom logging mechanism)
      RAISE; -- Re-raise the exception
  END;
END;
/
