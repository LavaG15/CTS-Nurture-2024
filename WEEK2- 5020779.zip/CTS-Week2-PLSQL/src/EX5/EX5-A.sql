/*
Exercise 5: Triggers

Scenario 1: Automatically update the last modified date when a customer's record is updated.
Question: Write a trigger UpdateCustomerLastModified that updates the LastModified column of the Customers table to the current date whenever a customer's record is updated.

*/

CREATE OR REPLACE TRIGGER UpdateCustomerLastModified
AFTER UPDATE ON Customers
FOR EACH ROW
BEGIN
  UPDATE Customers
  SET LastModified = SYSDATE
  WHERE CustomerID = :OLD.CustomerID;
END;
/
