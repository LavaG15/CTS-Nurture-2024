/*
Scenario 3: Enforce business rules on deposits and withdrawals.
Question: Write a trigger CheckTransactionRules that ensures withdrawals do not exceed the balance and deposits are positive before inserting a record into the Transactions table.


*/

CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
BEGIN
  IF :NEW.TransactionType = 'Withdrawal' THEN
    IF :NEW.Amount > (SELECT balance FROM accounts WHERE account_id = :NEW.account_id) THEN
      RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds');
    END IF;
  ELSIF :NEW.TransactionType = 'Deposit' THEN
    IF :NEW.Amount <= 0 THEN
      RAISE_APPLICATION_ERROR(-20002, 'Deposit amount must be positive');
    END IF;
  END IF;
END;
