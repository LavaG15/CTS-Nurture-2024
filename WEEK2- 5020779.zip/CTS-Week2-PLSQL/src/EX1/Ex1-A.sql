/* 
Exercise 1: Control Structures

Scenario 1: The bank wants to apply a discount to loan interest rates for customers above 60 years old.
Question: Write a PL/SQL block that loops through all customers, checks their age, and if they are above 60, apply a 1% discount to their current loan interest rates.

*/

DECLARE
  CURSOR cust_cursor IS
    SELECT l.loan_id, c.age, l.interest_rate
    FROM loans l
    JOIN customers c ON l.customer_id = c.customer_id;
  v_loan_id NUMBER;
  v_age NUMBER;
  v_interest_rate NUMBER;
BEGIN
  OPEN cust_cursor;
  LOOP
    FETCH cust_cursor INTO v_loan_id, v_age, v_interest_rate;
    EXIT WHEN cust_cursor%NOTFOUND;

    IF v_age > 60 THEN
      UPDATE loans
      SET interest_rate = interest_rate * 0.99
      WHERE loan_id = v_loan_id;
    END IF;
  END LOOP;
  CLOSE cust_cursor;
END;




