/*
Scenario 2: A customer can be promoted to VIP status based on their balance.
Question: Write a PL/SQL block that iterates through all customers and sets a flag IsVIP to TRUE for those with a balance over $10,000.
*/

UPDATE customers
SET is_vip = 'TRUE'
WHERE balance > 10000;
