/*
Scenario 3: The bank wants to send reminders to customers whose loans are due within the next 30 days.
Question: Write a PL/SQL block that fetches all loans due in the next 30 days and prints a reminder message for each customer.
*/

DECLARE
  CURSOR loan_cursor IS
    SELECT c.customer_id, c.name
    FROM loans l
    JOIN customers c ON l.customer_id = c.customer_id
    WHERE l.due_date BETWEEN SYSDATE AND SYSDATE + 30;
  v_customer_id NUMBER;
  v_customer_name VARCHAR2(100);
BEGIN
  OPEN loan_cursor;
  LOOP
    FETCH loan_cursor INTO v_customer_id, v_customer_name;
    EXIT WHEN loan_cursor%NOTFOUND;

    DBMS_OUTPUT.PUT_LINE('Reminder for customer ' || v_customer_name || ' (ID: ' || v_customer_id || '): Loan due in next 30 days.');
  END LOOP;
  CLOSE loan_cursor;
END;
