package LibraryMS;
public class LMS{

    
    public static class Book {
        int bookId;
        String title;
        String author;

        public Book(int bookId, String title, String author) {
            this.bookId = bookId;
            this.title = title;
            this.author = author;
        }

        @Override
        public String toString() {
            return "Book{" +
                    "bookId=" + bookId +
                    ", title='" + title + '\'' +
                    ", author='" + author + '\'' +
                    '}';
        }
    }

    public static Book linearSearch(Book[] books, String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public static Book binarySearch(Book[] books, String title, int low, int high) {
        if (low <= high) {
            int mid = (low + high) / 2;
            int cmp = books[mid].title.compareToIgnoreCase(title);

            if (cmp == 0) {
                return books[mid];
            } else if (cmp < 0) {
                return binarySearch(books, title, mid + 1, high);
            } else {
                return binarySearch(books, title, low, mid - 1);
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "Java Programming", "Priya"),
            new Book(2, "Data Structures", "Akshay"),
            new Book(3, "Algorithm Design", "Tanya"),
            new Book(4, "Database Systems", "Meera")
        };

        java.util.Arrays.sort(books, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));

        String searchTitle = "Data Structures";
        Book foundBook = linearSearch(books, searchTitle);
        System.out.println("Linear Search result for '" + searchTitle + "': " + (foundBook != null ? foundBook : "Book not found"));
        foundBook = binarySearch(books, searchTitle, 0, books.length - 1);
        System.out.println("Binary Search result for '" + searchTitle + "': " + (foundBook != null ? foundBook : "Book not found"));
    }
}

