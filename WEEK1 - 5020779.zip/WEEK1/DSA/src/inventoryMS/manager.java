package inventoryMS;

import java.util.HashMap;
import java.util.Map;

public class manager {
    private Map<Integer, Product> inventory;

    public manager() {
        inventory = new HashMap<>();
    }

    
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
        System.out.println("Product added: " + product);
    }

    
    public void updateProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            inventory.put(product.getProductId(), product);
            System.out.println("Product updated: " + product);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }

    
    public void deleteProduct(int productId) {
        if (inventory.containsKey(productId)) {
            Product removedProduct = inventory.remove(productId);
            System.out.println("Product deleted: " + removedProduct);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }

    
    public void displayInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Inventory is empty.");
        } else {
            System.out.println("Current Inventory:");
            for (Product product : inventory.values()) {
                System.out.println(product);
            }
        }
    }

    public static void main(String[] args) {
        manager manager = new manager();

        
        Product product1 = new Product(1, "Television", 10, 1500);
        Product product2 = new Product(2, "Smartphone", 50, 800);
        manager.addProduct(product1);
        manager.addProduct(product2);

        
        manager.displayInventory();

        
        product1.setQuantity(20);
        manager.updateProduct(product1);

       
        manager.deleteProduct(2);

        
        manager.displayInventory();
    }
}
