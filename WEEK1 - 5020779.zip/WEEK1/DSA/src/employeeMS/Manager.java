package employeeMS;

import java.util.Arrays;

public class Manager {
    private Employee[] employees;
    private int size;
    private static final int INITIAL_CAPACITY = 10;

    public Manager() {
        employees = new Employee[INITIAL_CAPACITY];
        size = 0;
    }

    public void addEmployee(Employee employee) {
        if (size == employees.length) {
            employees = Arrays.copyOf(employees, employees.length * 2);
        }
        employees[size++] = employee;
        System.out.println("Employee added: " + employee);
    }

    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--size] = null;
                System.out.println("Employee deleted with ID: " + employeeId);
                return;
            }
        }
        System.out.println("Employee not found with ID: " + employeeId);
    }

    public void traverseEmployees() {
        if (size == 0) {
            System.out.println("No employees in the system.");
            return;
        }
        System.out.println("Employee List:");
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public static void main(String[] args) {
        Manager manager = new Manager();

        Employee emp1 = new Employee(1, "Mounika", "Developer", 80000);
        Employee emp2 = new Employee(2, "Iakkiya", "Designer", 70000);
        Employee emp3 = new Employee(3, "Gopika", "Manager", 90000);

        manager.addEmployee(emp1);
        manager.addEmployee(emp2);
        manager.addEmployee(emp3);

        manager.traverseEmployees();

        System.out.println("Searching for employee with ID 2:");
        Employee foundEmployee = manager.searchEmployee(2);
        System.out.println(foundEmployee);

        System.out.println("Deleting employee with ID 2:");
        manager.deleteEmployee(2);

        manager.traverseEmployees();
    }
}
