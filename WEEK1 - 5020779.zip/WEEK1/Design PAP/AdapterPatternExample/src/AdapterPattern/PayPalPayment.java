package AdapterPattern;

public class PayPalPayment {

	public void payWithPayPal(double amount) {
        System.out.println("Processing payment with PayPal: $" + amount);
    }
}
