package dependencyInjection;

import java.util.List;

public class testing {
    public static void main(String[] args) {
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        List<Customer> customers = customerRepository.findCustomersById(1, 2, 3);

        for (Customer customer : customers) {
            System.out.println(customer);
        }
    }
}
