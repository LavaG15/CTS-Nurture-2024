package commandpattern;

import java.util.Scanner;

public class testing {
    public static void main(String[] args) {
       
        Light light = new Light();

        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);
        RemoteControl remote = new RemoteControl();

        
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Would you like to turn ON / OFF the light? ");
            String commandInput = scanner.nextLine().trim().toLowerCase();

            switch (commandInput) {
                case "on":
                    remote.setCommand(lightOn);
                    remote.pressButton();
                    System.out.println("The light is now on.");
                    break;
                case "off":
                    remote.setCommand(lightOff);
                    remote.pressButton();
                    System.out.println("The light is now off.");
                    break;
                case "exit":
                    System.out.println("No activity");
                    scanner.close();
                    return;
                default:
                    System.out.println("Try again !");
            }
        }
    }
}
