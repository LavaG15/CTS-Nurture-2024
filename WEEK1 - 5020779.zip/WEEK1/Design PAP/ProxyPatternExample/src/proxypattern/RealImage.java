package proxypattern;

public class RealImage implements Image {
    private String filename;
    private String imageType;

    public RealImage(String filename, String imageType) {
        this.filename = filename;
        this.imageType = imageType;
        loadImageFromServer();
    }

    private void loadImageFromServer() {
        System.out.println("Loading image: " + filename + " of type: " + imageType);
        // Simulate loading image from a remote server
    }

    @Override
    public void display() {
        System.out.println("Displaying image: " + filename + " of type: " + imageType);
    }
}
