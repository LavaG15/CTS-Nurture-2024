package proxypattern;

public class ProxyImage implements Image {
    private RealImage realImage;
    private String filename;
    private String imageType;

    public ProxyImage(String filename, String imageType) {
        this.filename = filename;
        this.imageType = imageType;
    }

    @Override
    public void display() {
        if (realImage == null) {
            realImage = new RealImage(filename, imageType); // Lazy initialization with image type
        }
        realImage.display(); // Delegate the call to the real object
    }
}
