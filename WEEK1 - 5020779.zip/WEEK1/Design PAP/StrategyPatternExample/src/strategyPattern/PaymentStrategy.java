package strategyPattern;

public interface PaymentStrategy {
	 void pay(int amount);

}
