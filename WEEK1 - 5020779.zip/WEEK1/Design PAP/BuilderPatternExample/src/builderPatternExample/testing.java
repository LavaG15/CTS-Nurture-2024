package builderPatternExample;

public class testing {
	    public static void main(String[] args) {
	        
	        Computer basicComputer = new Computer.Builder("Intel i5", 8)
	                .build();
	        System.out.println(basicComputer);

	        
	        Computer gamingComputer = new Computer.Builder("AMD Ryzen 7", 16)
	                .storage(512)
	                .hasGraphicsCard(true)
	                .hasWiFi(true)
	                .build();
	        System.out.println(gamingComputer);

	       
	        Computer officeComputer = new Computer.Builder("Intel i3", 4)
	                .storage(256)
	                .build();
	        System.out.println(officeComputer);
	    }
	}


