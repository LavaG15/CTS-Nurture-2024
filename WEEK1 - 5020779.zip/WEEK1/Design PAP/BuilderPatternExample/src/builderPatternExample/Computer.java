package builderPatternExample;

public class Computer {
	
    private String CPU;
    private int RAM;
    private int storage;
    private boolean hasGraphicsCard;
    private boolean hasWiFi;

    
    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.hasGraphicsCard = builder.hasGraphicsCard;
        this.hasWiFi = builder.hasWiFi;
    }

    @Override
    public String toString() {
        return "Computer{" +
                "CPU='" + CPU + '\'' +
                ", RAM=" + RAM +
                "GB, Storage=" + storage +
                "GB, GraphicsCard=" + (hasGraphicsCard ? "Yes" : "No") +
                ", WiFi=" + (hasWiFi ? "Yes" : "No") +
                '}';
    }

    
    public static class Builder {
    	// TODO Auto-generated method stub
        
        private String CPU;
        private int RAM;

        
        private int storage = 0;
        private boolean hasGraphicsCard = false;
        private boolean hasWiFi = false;

        public Builder(String CPU, int RAM) {
            this.CPU = CPU;
            this.RAM = RAM;
        }

        public Builder storage(int storage) {
            this.storage = storage;
            return this;
        }

        public Builder hasGraphicsCard(boolean hasGraphicsCard) {
            this.hasGraphicsCard = hasGraphicsCard;
            return this;
        }

        public Builder hasWiFi(boolean hasWiFi) {
            this.hasWiFi = hasWiFi;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }
}
