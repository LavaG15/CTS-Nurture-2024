package DecoratorPattern;

public class testing {
	public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier smsAndEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackAndSmsAndEmailNotifier = new SlackNotifierDecorator(smsAndEmailNotifier);

        System.out.println("Email Notification:");
        emailNotifier.send("Hello via Email!");

        System.out.println("\nEmail and SMS Notification:");
        smsAndEmailNotifier.send("Hello via Email and SMS!");

        System.out.println("\nEmail, SMS, and Slack Notification:");
        slackAndSmsAndEmailNotifier.send("Hello via Email, SMS, and Slack!");

    }

}
