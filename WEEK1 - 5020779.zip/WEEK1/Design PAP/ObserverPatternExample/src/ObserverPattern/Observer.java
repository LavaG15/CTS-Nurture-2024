package ObserverPattern;

interface Observer {
    void update(double price);
}
