package financial_forcasting;

import java.util.Scanner;

//import java.util.Scanner;

public class Forecasting {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter initial value:  ");
		double initialValue=sc.nextDouble();
				//double initialValue = 1000.0;  
		System.out.println("Enter Annual growth rate:  ");
		double annualGrowthRate=sc.nextDouble();
        //double annualGrowthRate = 0.05; 
		System.out.println("Enter no of years:  ");
		int years= sc.nextInt();
        //int years = 10; 

        double futureValue = calculateFutureValue(initialValue, annualGrowthRate, years);
        System.out.println("Future value after " + years + " years: " + futureValue);
	}
		public static double calculateFutureValue(double initialValue, double growthRate, int years) {
			if (years == 0) {
				return initialValue;
			}
			double futureValue = calculateFutureValue(initialValue, growthRate, years - 1);
			return futureValue * (1 + growthRate);
			}

}
