package AdapterPattern;

public class testing {
public static void main(String[] args) {
        
        PayPalPayment payPalPayment = new PayPalPayment();
        StripePayment stripePayment = new StripePayment();

        
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalPayment);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripePayment);

        
        payPalAdapter.processPayment(100.00);
        stripeAdapter.processPayment(200.00);
    }

}
