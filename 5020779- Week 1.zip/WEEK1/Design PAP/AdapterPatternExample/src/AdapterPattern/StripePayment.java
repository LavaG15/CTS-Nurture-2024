package AdapterPattern;

public class StripePayment {
	public void chargeWithStripe(double amount) {
        System.out.println("Processing payment with Stripe: $" + amount);
    }
}
