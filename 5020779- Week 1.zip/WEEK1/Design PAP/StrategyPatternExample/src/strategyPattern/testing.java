package strategyPattern;

public class testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 PaymentContext context = new PaymentContext();

	        
	        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "Priya");
	        context.setPaymentStrategy(creditCardPayment);
	        context.executePayment(100);

	        
	        PaymentStrategy payPalPayment = new PayPalPayment("priya@example.com");
	        context.setPaymentStrategy(payPalPayment);
	        context.executePayment(200);
	    }

	}

