package MVCPattern;

public class testing {

    public static void main(String[] args) {
        
        Student model = new Student();
        model.setName("Nilanjana");
        model.setId("51");
        model.setGrade("O");

     
        StudentView view = new StudentView();
   
        StudentController controller = new StudentController(model, view);

        controller.updateView();

        System.err.println();
        controller.setStudentName("Madhullika");
        controller.setStudentId("42");
        controller.setStudentGrade("A+");

       
        controller.updateView();
    }
}