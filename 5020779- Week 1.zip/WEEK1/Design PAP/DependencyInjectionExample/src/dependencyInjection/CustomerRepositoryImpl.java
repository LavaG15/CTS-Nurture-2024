package dependencyInjection;

import java.util.ArrayList;
import java.util.List;

public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public List<Customer> findCustomersById(int... ids) {
        List<Customer> customers = new ArrayList<>();
        for (int id : ids) {
            // Simulate finding a customer. In real scenarios, this might be a database query.
            customers.add(new Customer(id, "Customer" + id));
        }
        return customers;
    }
}
