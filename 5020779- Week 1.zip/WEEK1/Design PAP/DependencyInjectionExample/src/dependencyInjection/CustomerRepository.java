package dependencyInjection;
import java.util.List;

public interface CustomerRepository {
	List<Customer> findCustomersById(int... ids);

}
