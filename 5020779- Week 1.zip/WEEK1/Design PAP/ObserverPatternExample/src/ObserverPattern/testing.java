package ObserverPattern;

public class testing {
	public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        System.out.println("Stock Price: $100.00");
        stockMarket.setStockPrice(100.00);

        System.out.println();

        System.out.println("Stock Price: $120.00");
        stockMarket.setStockPrice(120.00);
    }

}
