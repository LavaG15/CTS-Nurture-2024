package proxypattern;

import java.util.Scanner;

public class testing {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of images to upload:");
        int numberOfImages = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        for (int i = 0; i < numberOfImages; i++) {
            System.out.println("Enter filename for image " + (i + 1) + ":");
            String filename = scanner.nextLine();

            System.out.println("Enter type for image " + (i + 1) + " (e.g., JPEG, PNG, GIF):");
            String imageType = scanner.nextLine();

            Image image = new ProxyImage(filename, imageType);
            image.display();
            System.out.println();
        }

        scanner.close();
    }
}
