package FactoryMethodPattern;

interface Document {
    void open();
}

public class WordDocument implements Document {
    @Override
    public void open() {
        System.out.println("Your word document is loading...");
    }
}
