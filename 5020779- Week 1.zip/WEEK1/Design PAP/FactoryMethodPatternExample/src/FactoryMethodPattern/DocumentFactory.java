package FactoryMethodPattern;

public abstract class DocumentFactory {
	public abstract Document createDocument();
	}


